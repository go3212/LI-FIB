#!/bin/bash

./misat < ./Random3SAT/vars-300-10.cnf